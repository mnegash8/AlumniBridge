import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight, Award, BriefcaseBusiness, Check, CheckCircle2, Circle,
  ClipboardCheck, FileText, Flag, GraduationCap, Plus, Sparkles, Target,
  Trophy, Users, X
} from 'lucide-react';

const STORAGE_KEY = 'alumnibridge-career-journeys-v1';

const STARTER_MILESTONES = [
  { id: 'profile', title: 'Build your career profile', description: 'Add your résumé, education, skills, and career direction.', points: 50, icon: FileText },
  { id: 'mentor', title: 'Find your alumni mentor', description: 'Review personalized recommendations and choose a mentor to connect with.', points: 75, icon: Users },
  { id: 'meeting', title: 'Have your first mentor conversation', description: 'Book a session, prepare questions, and capture your next steps.', points: 100, icon: GraduationCap },
  { id: 'activities', title: 'Complete a career-building activity', description: 'Turn your mentor’s advice into a practical action and record what you learned.', points: 125, icon: ClipboardCheck },
  { id: 'achievement', title: 'Earn your first achievement', description: 'Submit evidence of a completed milestone for mentor or program review.', points: 150, icon: Award },
  { id: 'portfolio', title: 'Publish your career portfolio', description: 'Bring your goals, completed milestones, and learning reflections together.', points: 200, icon: BriefcaseBusiness }
];

const starterActivities = [
  'Update my résumé using mentor feedback',
  'Complete a mock interview',
  'Research five employers in my target field',
  'Create or improve a career portfolio',
  'Attend a networking or career event'
];

function readStore() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); }
  catch { return {}; }
}

function getLevel(points) {
  if (points >= 1000) return { name: 'Career Champion', next: null, floor: 1000 };
  if (points >= 600) return { name: 'Pathfinder', next: 1000, floor: 600 };
  if (points >= 300) return { name: 'Momentum Builder', next: 600, floor: 300 };
  if (points >= 100) return { name: 'Rising Connector', next: 300, floor: 100 };
  return { name: 'Getting Started', next: 100, floor: 0 };
}

export default function CareerJourney({ studentProfile, bookings = [] }) {
  const profileName = studentProfile?.name || studentProfile?.full_name || '';
  const [email, setEmail] = useState('');
  const [journey, setJourney] = useState(null);
  const [activity, setActivity] = useState('');
  const [customActivity, setCustomActivity] = useState('');
  const [reflection, setReflection] = useState('');
  const [showAddActivity, setShowAddActivity] = useState(false);
  const [notice, setNotice] = useState('');

  useEffect(() => {
    const store = readStore();
    const savedEmail = studentProfile?.email || store.lastEmail || '';
    setEmail(savedEmail);
    if (savedEmail) setJourney(store[savedEmail.toLowerCase()] || null);
  }, [studentProfile]);

  const saveJourney = (next, nextEmail = email) => {
    const key = nextEmail.trim().toLowerCase();
    if (!key) return;
    const store = readStore();
    store[key] = next;
    store.lastEmail = key;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
    setJourney(next);
  };

  const startJourney = (event) => {
    event.preventDefault();
    if (!email.trim()) return;
    const store = readStore();
    const key = email.trim().toLowerCase();
    const existing = store[key];
    const initial = existing || {
      name: profileName,
      goals: studentProfile?.goals || studentProfile?.target_role || '',
      milestones: [],
      activities: [],
      createdAt: new Date().toISOString()
    };
    store[key] = initial;
    store.lastEmail = key;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
    setJourney(initial);
    setNotice(existing ? 'Your saved journey is ready.' : 'Your career journey has been created.');
  };

  const completed = journey?.milestones || [];
  const completedCount = completed.length;
  const points = completed.reduce((sum, id) => sum + (STARTER_MILESTONES.find(m => m.id === id)?.points || 0), 0);
  const level = getLevel(points);
  const progress = Math.round((completedCount / STARTER_MILESTONES.length) * 100);
  const levelProgress = level.next ? Math.min(100, ((points - level.floor) / (level.next - level.floor)) * 100) : 100;

  const toggleMilestone = (id) => {
    const next = completed.includes(id) ? completed.filter(item => item !== id) : [...completed, id];
    saveJourney({ ...journey, milestones: next });
    setNotice(next.includes(id) ? 'Milestone marked complete. Demo points updated.' : 'Milestone moved back to in progress.');
  };

  const addActivity = (event) => {
    event.preventDefault();
    const title = (customActivity || activity).trim();
    if (!title) return;
    const nextActivity = {
      id: `${Date.now()}`,
      title,
      reflection: reflection.trim(),
      status: 'Submitted for review',
      createdAt: new Date().toISOString()
    };
    saveJourney({ ...journey, activities: [nextActivity, ...(journey.activities || [])] });
    setActivity('');
    setCustomActivity('');
    setReflection('');
    setShowAddActivity(false);
    setNotice('Activity saved. It is marked as submitted, not verified.');
  };

  const linkedBookings = useMemo(() => bookings.filter(b =>
    !email || (b.student_email || '').toLowerCase() === email.toLowerCase()
  ), [bookings, email]);

  if (!journey) {
    return (
      <section className="journey-page animate-fade-in">
        <div className="journey-hero">
          <div className="journey-eyebrow"><Sparkles size={15} /> YOUR NEXT CHAPTER STARTS HERE</div>
          <h1>Turn your ambition into <span>forward motion.</span></h1>
          <p>Build a career plan with alumni who have been where you want to go. Track the steps, reflect on what you learn, and create a portfolio of progress.</p>
        </div>
        <form className="journey-start-card glass-panel" onSubmit={startJourney}>
          <div className="journey-icon-orb"><Flag size={25} /></div>
          <h2>Start your Career Journey</h2>
          <p>Use your email to save and reopen this journey in this browser.</p>
          <label htmlFor="journey-email">Student email</label>
          <input id="journey-email" className="form-input" type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="you@university.edu" />
          <button className="btn-primary" type="submit">Create my journey <ArrowRight size={17} /></button>
          <small>Your journey is currently saved locally in this browser. Sign-in and secure cloud sync are not yet configured.</small>
        </form>
      </section>
    );
  }

  return (
    <section className="journey-page animate-fade-in">
      <div className="journey-hero journey-hero-row">
        <div>
          <div className="journey-eyebrow"><Sparkles size={15} /> YOUR CAREER, IN MOTION</div>
          <h1>{profileName ? `Keep moving forward, ${profileName.split(' ')[0]}.` : 'Your next chapter starts here.'}</h1>
          <p>A practical path from your current goals to your next opportunity.</p>
        </div>
        <div className="journey-level-pill"><Trophy size={17} /><span>{level.name}</span></div>
      </div>

      <div className="journey-overview-grid">
        <article className="journey-stat-card journey-progress-card">
          <div className="journey-stat-top"><span>Journey progress</span><Target size={18} /></div>
          <div className="journey-stat-value">{progress}%</div>
          <div className="journey-progress-track"><div style={{ width: `${progress}%` }} /></div>
          <small>{completedCount} of 6 milestones completed</small>
        </article>
        <article className="journey-stat-card">
          <div className="journey-stat-top"><span>Career points</span><Sparkles size={18} /></div>
          <div className="journey-stat-value">{points.toLocaleString()} <small>XP</small></div>
          <div className="journey-level-track"><div style={{ width: `${levelProgress}%` }} /></div>
          <small>{level.next ? `${level.next - points} XP to ${level.next} XP level` : 'Highest demo level reached'}</small>
        </article>
        <article className="journey-stat-card">
          <div className="journey-stat-top"><span>Mentor sessions</span><Users size={18} /></div>
          <div className="journey-stat-value">{linkedBookings.length}</div>
          <small>Bookings associated with this email in the current demo</small>
        </article>
      </div>

      {notice && <div className="journey-notice" role="status"><CheckCircle2 size={16} />{notice}<button onClick={() => setNotice('')} aria-label="Dismiss"><X size={15} /></button></div>}

      <div className="journey-content-grid">
        <div className="journey-main-column">
          <div className="journey-section-heading">
            <div><span className="journey-kicker">THE ROADMAP</span><h2>Your six milestones</h2></div>
            <span className="journey-count">{completedCount}/6 complete</span>
          </div>
          <div className="journey-milestones">
            {STARTER_MILESTONES.map((item, index) => {
              const done = completed.includes(item.id);
              const Icon = item.icon;
              return (
                <article className={`journey-milestone ${done ? 'is-complete' : ''}`} key={item.id}>
                  <div className="journey-milestone-rail">
                    <div className="journey-milestone-icon">{done ? <Check size={18} /> : <Icon size={18} />}</div>
                    {index !== STARTER_MILESTONES.length - 1 && <div className="journey-rail-line" />}
                  </div>
                  <div className="journey-milestone-body">
                    <div className="journey-milestone-top">
                      <div><span className="journey-step-label">STEP {String(index + 1).padStart(2, '0')}</span><h3>{item.title}</h3></div>
                      <span className="journey-xp">+{item.points} XP</span>
                    </div>
                    <p>{item.description}</p>
                    <button className={done ? 'journey-complete-btn' : 'journey-action-btn'} onClick={() => toggleMilestone(item.id)}>
                      {done ? <><CheckCircle2 size={15} /> Completed · Undo</> : <>Mark milestone complete <ArrowRight size={15} /></>}
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        </div>

        <aside className="journey-side-column">
          <article className="journey-side-card">
            <div className="journey-side-title"><div><span className="journey-kicker">TAKE ACTION</span><h3>Career activities</h3></div><ClipboardCheck size={20} /></div>
            <p>Turn a mentor conversation into a small, achievable next step.</p>
            <button className="btn-primary journey-full-btn" onClick={() => setShowAddActivity(v => !v)}><Plus size={16} /> Add an activity</button>
            {showAddActivity && (
              <form className="journey-activity-form" onSubmit={addActivity}>
                <label htmlFor="activity-choice">Choose an activity</label>
                <select id="activity-choice" className="form-select" value={activity} onChange={e => { setActivity(e.target.value); setCustomActivity(''); }}>
                  <option value="">Select a suggested activity</option>
                  {starterActivities.map(a => <option key={a} value={a}>{a}</option>)}
                  <option value="custom">Write my own activity</option>
                </select>
                {(activity === 'custom' || (!activity && customActivity)) && <input className="form-input" value={customActivity} onChange={e => setCustomActivity(e.target.value)} placeholder="Describe your activity" required />}
                <label htmlFor="activity-reflection">What will you do or what did you learn?</label>
                <textarea id="activity-reflection" className="form-textarea" value={reflection} onChange={e => setReflection(e.target.value)} placeholder="Add a short note..." rows={3} />
                <div className="journey-form-actions"><button type="button" className="btn-secondary" onClick={() => setShowAddActivity(false)}>Cancel</button><button type="submit" className="btn-primary">Save activity</button></div>
              </form>
            )}
            {(journey.activities || []).length === 0 ? <div className="journey-empty-state">Your activities will appear here once you add your first one.</div> :
              <div className="journey-activity-list">{journey.activities.map(a => <div className="journey-activity-item" key={a.id}><div className="journey-activity-dot"><Circle size={9} /></div><div><strong>{a.title}</strong><span>{a.status}</span>{a.reflection && <p>{a.reflection}</p>}</div></div>)}</div>}
          </article>

          <article className="journey-side-card">
            <div className="journey-side-title"><div><span className="journey-kicker">YOUR ACHIEVEMENTS</span><h3>Milestone badges</h3></div><Award size={20} /></div>
            <div className="journey-badge-grid">
              {STARTER_MILESTONES.map(m => {
                const unlocked = completed.includes(m.id);
                return <div className={`journey-badge ${unlocked ? 'unlocked' : ''}`} key={m.id} title={m.title}><div>{unlocked ? <Check size={17} /> : <Award size={17} />}</div><span>{m.title.replace('Build your ', '').replace('Find your ', '').replace('Have your first ', '').replace('Complete a ', '').replace('Earn your first ', '').replace('Publish your ', '')}</span></div>;
              })}
            </div>
          </article>

          <article className="journey-side-card journey-portfolio-card">
            <div className="journey-side-title"><div><span className="journey-kicker">CAREER PORTFOLIO</span><h3>Proof of your progress</h3></div><BriefcaseBusiness size={20} /></div>
            <p>Your completed milestones and activity reflections form the starting point of a portfolio you can share with mentors and career advisors.</p>
            <div className="journey-portfolio-summary"><span>{completedCount} completed milestones</span><span>{(journey.activities || []).length} activities recorded</span></div>
            <button className="btn-secondary journey-full-btn" onClick={() => window.print()}>Print journey summary <ArrowRight size={15} /></button>
          </article>
        </aside>
      </div>
      <div className="journey-footnote">Prototype note: progress and XP are demo-only and stored in this browser. A milestone marked complete is not independently verified. Real mentor approval, secure accounts, and university-wide records need to be connected before production use.</div>
    </section>
  );
}
